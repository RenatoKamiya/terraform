<html>
<head><title>Seu titulo aqui</title></head>
<body>
Funcionou!!!! Copiou!!!
Copiou di novo mesmooo o arquivo php!!

<?php phpinfo();?>
</body>
</html>
